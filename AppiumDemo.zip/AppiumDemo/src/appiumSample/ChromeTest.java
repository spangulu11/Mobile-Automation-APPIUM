package appiumSample;



import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class ChromeTest {

	public static void main(String[] args) {
		
		
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceName", "Nexus 6P");
		caps.setCapability("udid", "84B5T15A29006642"); //Give Device ID of your mobile phone
		caps.setCapability("platformName", "Andoid");
		caps.setCapability("platformVersion", "8.1.0");
		caps.setCapability("browserName", "Chrome");
		caps.setCapability("noReset", true);
	    System.setProperty("webdriver.chrome.driver",".\\Driver\\chromedriver.exe");
	    AppiumDriver<MobileElement> driver = null;
		try {
			driver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
			
		} catch (MalformedURLException e) {
			System.out.println(e.getMessage());
		}
				
		
		driver.get("http://www.google.com");		
	    String actual=driver.getTitle();	  
		Assert.assertEquals(actual, "Google");
		System.out.println("Title verfied succesfuly");
		driver.close();
	}
	
	
	
}
