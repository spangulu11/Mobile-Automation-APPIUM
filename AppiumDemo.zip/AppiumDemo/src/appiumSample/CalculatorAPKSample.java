package appiumSample;

import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.*;


public class CalculatorAPKSample {
WebDriver driver;

@BeforeClass
public void setUp() throws MalformedURLException{
	
	DesiredCapabilities capabilities = new DesiredCapabilities();
	capabilities.setCapability("BROWSER_NAME", "Android");
	capabilities.setCapability("VERSION", "8.1.0"); 
	capabilities.setCapability("deviceName","Nexus 6P");
	capabilities.setCapability("platformName","Android");   
    capabilities.setCapability("appPackage", "com.google.android.calculator");
    capabilities.setCapability("appActivity","com.android.calculator2.Calculator");
    driver = new RemoteWebDriver(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
}

@Test
public void testCal() throws Exception {
	
	System.out.println("Calculate sum of two numbers");
	
	driver.findElement(By.name("1")).click();
	driver.findElement(By.name("+")).click();
	driver.findElement(By.name("2")).click();
	driver.findElement(By.name("=")).click();
	
	
	WebElement sumOfNumbersEle = driver.findElement(By.className("android.widget.EditText"));
	String sumOfNumbers = sumOfNumbersEle.getText();
	

	Assert.assertTrue(sumOfNumbers.endsWith("3"));
  
}

@AfterClass
public void teardown(){

	driver.quit();
}
}