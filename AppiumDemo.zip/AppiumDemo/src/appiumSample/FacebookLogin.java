package appiumSample;

import java.net.MalformedURLException;
import java.net.URL;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
 
public class FacebookLogin
{
 
	WebDriver driver;
	
@SuppressWarnings("rawtypes")
@Test
public void test1() throws MalformedURLException{
 
		DesiredCapabilities capabilities=DesiredCapabilities.android();
		capabilities.setCapability(MobileCapabilityType.BROWSER_NAME,BrowserType.CHROME);
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME,"Android");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,"Nexus 6P");
		capabilities.setCapability(MobileCapabilityType.VERSION,"8.1.0");
		URL url= new URL("http://0.0.0.0:4723/wd/hub");
		 
		driver = new AndroidDriver(url, capabilities);
		driver.get("http://www.facebook.com");
		System.out.println("Title "+driver.getTitle());
		driver.findElement(By.name("email")).sendKeys("appiumgk@gmail.com");
		driver.findElement(By.name("pass")).sendKeys("Rbsps@123");
		driver.findElement(By.id("u_0_5")).click();
		WebDriverWait wt=new WebDriverWait(driver, 5);
		WebElement ele=wt.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@value='OK']")));
		ele.click();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		capabilities.setCapability("autoAcceptAlerts", true);
		capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, "UnexpectedAlertBehaviour.ACCEPT");
		capabilities.setCapability("autoDismissAlerts", true);
		capabilities.setCapability(AndroidMobileCapabilityType.AUTO_GRANT_PERMISSIONS, true);
		driver.findElement(By.xpath("//a[@id='u_0_j']//div[@class='_59tf _2ftq']")).click();
		driver.quit();

}

 
 
 
}
		 
		
		 
		 
		 
		
		 
		 
		

		
				
		 
	
 
		
 

 
 
 
  
 

   
 
 

