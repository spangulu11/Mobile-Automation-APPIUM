package appiumSample;


import io.appium.java_client.android.AndroidDriver;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class SelendrioAPKTest {
@SuppressWarnings("rawtypes")
private static AndroidDriver driver;

@SuppressWarnings("rawtypes")
public static void main(String[] args) throws MalformedURLException, InterruptedException 
{
	DesiredCapabilities capabilities = new DesiredCapabilities();
	capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
	capabilities.setCapability("deviceName", "Nexus 6P");
	capabilities.setCapability("platformVersion", "8.1.0");
	capabilities.setCapability("platformName", "Android");
	capabilities.setCapability("appPackage", "io.selendroid.testapp");
	capabilities.setCapability("appActivity", ".HomeScreenActivity");
	driver = new AndroidDriver(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);	
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);	
	driver.findElement(By.xpath("//android.widget.EditText[@content-desc='my_text_fieldCD']")).sendKeys(" Selenium Appium");	
	driver.findElement(By.id("io.selendroid.testapp:id/startUserRegistration")).click();	
	Thread.sleep(10000);
	driver.quit();
	
}
}
